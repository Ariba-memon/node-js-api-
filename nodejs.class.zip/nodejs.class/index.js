const express = require('express');
const cors = require('cors');
const bod = require('body-parser');
const app = express();
const port = 5000;


app.use(cors());
app.use(bod.urlencoded({
    extended:false
}))

app.use(bod.json());
app.get('/',(req,res)=>{
    res.send('hello to first api');
})

app.listen(port,()=>{
    console.log(' server is running')
})
app.post('/signup',(req,res)=>{
    // res.send('signup api')
    console.log(req.body.email)
})